const express = require('express');
const mysql = require("mysql2");
const port = process.env.PORT || 500;

const app = express();

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Nono2005_',
    database: 'RESTAURANT'
});

connection.connect((err) => {
    if (err) {
        console.error("Erreur de connexion : " + err.stack);
        return;
    }
    console.log("Connexion réussie à la base de données");
});

app.use(express.json());

app.get("/items", (req, res) => {
    connection.query("SELECT * FROM ITEM", (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get("/formula", (req, res) => {
    connection.query("SELECT * FROM FORMULA", (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get("/category/starters", (req, res) => {
    connection.query('SELECT category_name, ids, item_name, item_price FROM CATEGORY INNER JOIN ITEM ON category_id = ITEM.ids WHERE ids = 1', (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get("/category/mains", (req, res) => {
    connection.query('SELECT category_name, ids, item_name, item_price FROM CATEGORY INNER JOIN ITEM ON category_id = ITEM.ids WHERE ids = 2', (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get("/category/sides", (req, res) => {
    connection.query('SELECT category_name, ids, item_name, item_price FROM CATEGORY INNER JOIN ITEM ON category_id = ITEM.ids WHERE ids = 3', (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get("/category/drinks", (req, res) => {
    connection.query('SELECT category_name, ids, item_name, item_price FROM CATEGORY INNER JOIN ITEM ON category_id = ITEM.ids WHERE ids = 4', (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get("/category/desserts", (req, res) => {
    connection.query('SELECT category_name, ids, item_name, item_price FROM CATEGORY INNER JOIN ITEM ON category_id = ITEM.ids WHERE ids = 5', (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get('/itemcat', (req, res) => {
    const parameters = req.query.parameters;

    if (!parameters) {
        connection.query('SELECT * FROM ITEM', (err, rows, fields) => {
            if (err) throw err;
            res.json(rows);
        });
    } else {
        const sqlQuery = `SELECT item_name, item_description, item_price FROM ITEM WHERE ${parameters}`;
        connection.query(sqlQuery, (err, rows, fields) => {
            if (err) throw err;
            res.json(rows);
        });
    }
});

app.get('/items/:item_id', (req, res) => {
    const idItems = req.params.item_id;

    const sqlQueryid = 'SELECT item_name, item_description, item_price FROM ITEM WHERE item_id = ?';
    connection.query(sqlQueryid, [idItems], (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get('/category/:category_id', (req, res) => {
    const idCategory = req.params.category_id;

    const sqlQueryid = 'SELECT category_name, category_description FROM CATEGORY WHERE category_id = ?';
    connection.query(sqlQueryid, [idCategory], (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.get('/formula/:formula_id', (req, res) => {
    const idFormula = req.params.formula_id;

    const sqlQueryid = 'SELECT categories_in_formula, formula_price FROM FORMULA WHERE formula_id = ?';
    connection.query(sqlQueryid, [idFormula], (err, rows, fields) => {
        if (err) throw err;
        res.json(rows);
    });
});

app.delete('/delitems/:item_id', (req, res) => {
    const idItems = req.params.item_id;

    const sqlQueryid = 'DELETE FROM ITEM WHERE item_id = ?';
    connection.query(sqlQueryid, [idItems], (err, rows, fields) => {
        if (err) throw err;
        res.json({ message: 'Item deleted' });
    });
});

app.delete('/delformula/:formula_id', (req, res) => {
    const idFormula = req.params.formula_id;

    const sqlQueryid = 'DELETE FROM FORMULA WHERE formula_id = ?';
    connection.query(sqlQueryid, [idFormula], (err, rows, fields) => {
        if (err) throw err;
        res.json({ message: 'Formula deleted' });
    });
});

app.post('/category', (req, res) => {
    const { category_name } = req.body;
    connection.query('INSERT INTO category (category_name) VALUES (?)', [category_name], (error, results) => {
        if (error) {
            console.error('Error inserting record:', error);
            res.status(500).json({ message: 'Internal Server Error' });
        } else {
            res.status(201).json({ message: 'Record inserted successfully' });
        }
    });
});



app.post('/formula', (req, res) => {
    const { formula_name } = req.body;
    connection.query('INSERT INTO FORMULA (formula_name) VALUES (?)', [formula_name], (error, results) => {
        if (error) {
            console.error('Error inserting record:', error);
            res.status(500).json({ message: 'Internal Server Error' });
        } else {
            res.status(201).json({ message: 'Record inserted successfully' });
        }
    });
});



app.post('/item', (req, res) => {
    const { item_name } = req.body;
    connection.query('INSERT INTO ITEM (item_name) VALUES (?)', [item_name], (error, results) => {
        if (error) {
            console.error('Error inserting record:', error);
            res.status(500).json({ message: 'Internal Server Error' });
        } else {
            res.status(201).json({ message: 'Record inserted successfully' });
        }
    });
});


app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});
